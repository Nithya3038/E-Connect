import React from "react";

function Admin() {
  return <div>admin</div>;
}

export default Admin;
