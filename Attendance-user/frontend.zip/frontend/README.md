Internal ERP
.\rbg\Scripts\activate
python -m uvicorn Server:app --reload